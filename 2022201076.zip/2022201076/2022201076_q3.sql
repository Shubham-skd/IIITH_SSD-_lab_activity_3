select Mgr_ssn, count(Pnumber) as No_of_Projects from PROJECT,DEPARTMENT where Dnumber=Dnum and Dnum in(select a.Dnum from PROJECT a where Pname="productY");

